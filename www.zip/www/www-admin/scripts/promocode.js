﻿(function () {

    var imagenew = "";
    var promo;
    var description;
    var amount;




    $(document).on("pagebeforecreate", function () {
        printheader();
    });

    $(document).ready(function () {
        //$("#itemForm").validate({
        //    rules: {
        //        itemName: true,

        //        price: {
        //            number: true
        //        }
        //    },
        //    messages: {
        //        itemName: "Item Name is required",
        //        description: "Please fill in a description",
        //        price: "Enter a price"

        //    },
        //    focusInvalid: false,
        //    submitHandler: function () {
        //        return false;
        //    },
        //    errorPlacement: function (error, element) {
        //        error.appendTo(element.parent().parent().after());
        //    }
        //});

        $("#btnSelectImg").bind("click", function () {
            capturePhoto();
        });

        $("#btnCreate").bind("click", function () {

            newitem();


        });


    });




    //Image Section
    function capturePhoto() {
        var source = navigator.camera.PictureSourceType.PHOTOLIBRARY;
        navigator.camera.getPicture(_onPhotoURISuccess, _failCapture, { quality: 50, destinationType: navigator.camera.DestinationType.FILE_URI, sourceType: source });
    }

    function _failUpload(error) {
        validationMsgs("Error:" + error.code, "Upload Error", "Try Again");
    }

    function _failCapture(message) {
        validationMsgs("Error:" + message, "Image Error", "Try Again");
    }

    function _onPhotoURISuccess(imageURI) {
        var options = new FileUploadOptions();
        options.fileKey = "file";
        options.fileName = imageURI.substr(imageURI.lastIndexOf('/') + 1);
        options.mimeType = "image/jpeg";

        var params = new Object();
        params.value1 = "test";
        params.value2 = "param";
        options.params = params;
        options.chunkedMode = false;
        options.headers = { Connection: "close" };
        var ft = new FileTransfer();
        ft.upload(imageURI, serverURL() + "/upload.php", _winUpload, _failUpload, options);
    }

    function _winUpload(r) {
        if (imagenew !== "") {
            _deleteOldImg(imagenew);
        }
        var arr = JSON.parse(r.response);
        imagenew = arr[0].result;
        $("#imgitem").attr("src", serverURL() + "/images/" + imagenew + "_s");
    }

    function _deleteOldImg(oldImg) {
        var url = serverURL() + "/deleteimg.php";

        var JSONObject = {
            "imgfile": oldImg
        };

        $.ajax({
            url: url,
            type: 'GET',
            data: JSONObject,
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function (arr) {
                _deleteImgResult(arr);
            },
            error: function () {
                validationMsg();
            }
        });
    }

    function _deleteImgResult(arr) {
        if (arr[0].result !== "1") {
            validationMsgs("Error deleteing old image", "Upload Error", "Try Again");
        }
    }


    //New item Saving Section
    function newitem() {
        //if ($("#itemForm").valid()) {
        var imagefile = imagenew;


        promo = $("#promo").val();
        amount = $("#amount").val();
        description = $("#description").val();



        //if (_validate()) {
        var url = serverURL() + "/promo.php";

        var JSONObject = {
            "promo": promo,
            "amount": amount,
            "description": description,
            "imagefile": "hello"
        };

        $.ajax({
            url: url,
            type: 'GET',
            data: JSONObject,
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function (arr) {
                newitemre(arr);

            },
            error: function () {
                validationMsg();
            }
        });
        //}
        //}
    }

   

    function newitemre(arr) {
        if (arr[0].result === 1) {

            validationMsgs("New item Created", "Validation", "OK");

        }
        else {
            validationMsgs("User ID already exist", "Validation", "OK");
        }
    }







})();