﻿(function () {

    var orders;


    $(document).on("pagebeforecreate", function () {
        printheader();
    });

    $(document).ready(function () {
        vieworder();

        $("#btndel").bind("click", function () {
            updatedel();
        });


    });

    function vieworder() {
        var url = serverURL() + "/getorderbyid.php";

        orders = decodeURIComponent(getUrlVars()["orderID"]);

        var JSONObject = {
            "orderID": decodeURIComponent(getUrlVars()["orderID"])
        };

        $.ajax({
            url: url,
            type: 'GET',
            data: JSONObject,
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function (arr) {
                _vieworder2(arr);
            },
            error: function () {
                validationMsg();
            }
        });
    }

    function _vieworder2(arr) {

        $("#imgProfileImage").attr("src", serverURL() + "/images/" + arr[0].imagefile);
        $("#lblProfileUsername").html("Item: " + arr[0].itemName);
        $("#lblProfileDescription").html("Price per Quantity: " + arr[0].price);
        $("#lblProfileDesc").html("Quantity: " + arr[0].quantity);
        $("#lblorderaddress").html("To deliver to: " + arr[0].orderaddress);
        $("#lblrequest").html("Special Request: " + arr[0].request);
        $("#lblProfile").html("To deliver by: " + arr[0].requestedDateTime);
        localStorage.setItem("orderID", orders);

    }

    //Description Section
    function updatedel() {
        var newdate = $("#delivery").val();

        var url = serverURL() + "/deliverorder.php";

        var JSONObject = {
            "orderID": localStorage.getItem("orderID"),
            "deliveredDateTime": newdate
        };

        $.ajax({
            url: url,
            type: 'GET',
            data: JSONObject,
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function (arr) {
                updatedel1(arr);
            },
            error: function () {
                validationMsg();
            }
        });
    }

    function updatedel1(arr) {
        if (arr[0].result === 1) {
            validationMsgs("changed", "Validation", "OK");
        }
        else {
            validationMsgs("Description update failed", "Validation", "Try Again");
        }
    }


})();