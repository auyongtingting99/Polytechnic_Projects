﻿(function () {

      $(document).on("pagebeforecreate", function () {
        printheader();
    });
   


    $(document).ready(function () {

        orders();

        $(document).on("pagebeforecreate", function () {
            printheader();
        });

    });

    function orders() {
    var url = serverURL() + "/getoutstandingorders.php";
    var JSONObject = {

     "status":"ord"
       
    };

    $.ajax({
        url: url,
        type: 'GET',
        data: JSONObject,
        dataType: 'json',
        contentType: "application/json; charset=utf-8",
        success: function (arr) {

            loop(arr);
           
        },
        error: function () {
            alert("");
        }
    });

    }

    function loop(arr) {
        var t;
        if ($.fn.dataTable.isDataTable('#searchresult')) {
            t = $('#searchresult').DataTable();
        }
        else {
            t = $('#searchresult').DataTable({
                "searching": false,
                "lengthChange": false
            });
        }
        t.clear();
        for (var i = 0; i < arr.length; i++) {
            t.row.add([
                arr[i].userID,
               //arr[i].userID, // replace image temporary
                "<img src='" + serverURL() + "/images/" + arr[i].imagefile + "_s" + "' width='50'>",
                arr[i].price,
                arr[i].requestedDateTime,
                "<a href='#' class='ui-btn' id='btn" + arr[i].orderID + "'>View</a>"]).draw(false);

            $("#btn" + arr[i].orderID).bind("click", { id: arr[i].orderID }, function (event) {
                var data = event.data;
                vieworder(data.id);
            });
            //$("#wallcontentset").append("<tr><td>" + arr[i].userID + "</td><td>" +  "</td><td>" + arr[i].price + "</td><td>" + arr[i].requestedDateTime + "</td><td><a href='#' id='btnview' class='ui-btn'>view</a></td></tr>");
        }
        $("#searchresult").show();

    }

    function vieworder(orderID) {
        window.location = "vieworder.html?orderID=" + orderID;

    }

})();