﻿
function printheader() {
    $("#header").html("<h1>Pizza Place</h1>");
    $("#header").append("<a href='#' id='btnHome' class='ui-btn ui-icon-home ui-btn-icon-left'>Home</a><a href='#' id='btnLogout' data-icon='power' class='ui-btn-right'>Logout</a>");

    var navbarstr = "<div data-role='navbar'><ul>";
    navbarstr += "<li><a id='btncatalogue' href='#' data-icon='location'>Catalogue</a></li>";
    navbarstr += "<li><a id='btnpromocode' href='#' data-icon='location'>PromoCode</a></li>";

    navbarstr += "</ul></div>";

    var myNavbar = $(navbarstr);
    $("#header").append(myNavbar).trigger('create');

    $("#btncatalogue").bind("click", function () {
        window.location = "catalog.html";
    });

    $("#btnpromocode").bind("click", function () {
        window.location = "promocode.html";
    });


    $("#btnHome").bind("click", function () {
        window.location = "orders.html";
    });


    $("#btnLogout").bind("click", function () {
        localStorage.removeItem("userid");
        localStorage.removeItem("password");
        window.location = "index.html";
    });
}


function serverURL() {
    return "http://1602348c.projectsbit.org/pizzaplace";
} 

function validationMsg() {
    validationMsgs("Unable to connect to server. Please try again later.", "Connection Problem", "OK");
} 


function validationMsgs(message, title, button) {
    navigator.notification.alert(
        message,
        function () { },
        title,
        button);
}

function round(number, decimals) {
    return +(Math.round(number + "e+" + decimals) + "e-" + decimals);
}

function getRadioValue(groupName) {
    var _result;
    try {
        var o_radio_group = document.getElementsByName(groupName);
        for (var a = 0; a < o_radio_group.length; a++) {
            if (o_radio_group[a].checked) {
                _result = o_radio_group[a].value;
                break;
            }
        }
    } catch (e) { }
    return _result;
} 


function getUrlVars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function (m, key, value) {
        vars[key] = value;
    });
    return vars;
}