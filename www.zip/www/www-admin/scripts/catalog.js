﻿(function () {

  var newimg = "";
    var itemName;
    var description;
    var price;
    var categoryID;
  

    $(document).on("pagebeforecreate", function () {
        printheader();
    });

    $(document).ready(function () {
        $("#NewUserForm").validate({
            rules: {
                itemName: {
                    itemName: true
                },
                price: {
                    number:true
                }
            },

            messages: {
                itemName: "Item Name is required",
                description: "Please fill in a description",
                price: "Enter a price"
            },
            focusInvalid: false,
            submitHandler: function () {
                return false;
            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().parent().after());
            }
        });

        

         $("#btnSelectImg").bind("click", function () {
            capturePhoto();
        });

         getRelationships();

         $("#btnCreateItem").bind("click", function () {
            savenewitem();
         });
    });

    function getRelationships() {
        var url = serverURL() + "/getcategories.php";
        $.ajax({
            url: url,
            type: 'GET',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function (arr) {
                _getRelationshipsResult(arr);
            },
            error: function () {
                validationMsg();
            }
        });
    }

    function _getRelationshipsResult(arr) {
        $('#categoryID')
            .find('option')
            .remove()
            .end();
  
        $("#categoryID").append($("<option>", {
            value: "-1",
            text: "Select a Category"
        }));
        for (var i = 0; i < arr.length; i++) {
            $("#categoryID").append($("<option>", {
                value: arr[i].categoryID,
                text: arr[i].categoryname
            }));
        }
        $("#categoryID").val("-1").change();
    }



    // Function of having the picture section 
function capturePhoto() {
    var source = navigator.camera.PictureSourceType.PHOTOLIBRARY;
    navigator.camera.getPicture(_onPhotoURISuccess, _failCapture, { quality: 50, destinationType: navigator.camera.DestinationType.FILE_URI, sourceType: source });
}

function _failUpload(error) {
    validationMsgs("Error:" + error.code, "Upload Error", "Try Again");
}

function _failCapture(message) {
    validationMsgs("Error:" + message, "Image Error", "Try Again");
}

function _onPhotoURISuccess(imageURI) {
    var options = new FileUploadOptions();
    options.fileKey = "file";
    options.fileName = imageURI.substr(imageURI.lastIndexOf('/') + 1);
    options.mimeType = "image/jpeg";

    var params = new Object();
    params.value1 = "test";
    params.value2 = "param";
    options.params = params;
    options.chunkedMode = false;
    options.headers = { Connection: "close" };
    var ft = new FileTransfer();
    ft.upload(imageURI, serverURL() + "/upload.php", _winUpload, _failUpload, options);
}

function _winUpload(r) {
    if (newimg !== "") {
        _deleteOldImg(newimg);
    }
    var arr = JSON.parse(r.response);
    newimg = arr[0].result;
    $("#Imgitem").attr("src", serverURL() + "/images/" + newimg + "_s");
}

function _deleteOldImg(oldImg) {
    var url = serverURL() + "/deleteimg.php";

    var JSONObject = {
        "imgfile": oldImg
    };

    $.ajax({
        url: url,
        type: 'GET',
        data: JSONObject,
        dataType: 'json',
        contentType: "application/json; charset=utf-8",
        success: function (arr) {
            _deleteImgResult(arr);
        },
        error: function () {
            validationMsg();
        }
    });
}

    function _deleteImgResult(arr) {
        if (arr[0].result !== "1") {
            validationMsgs("Error deleteing old image", "Upload Error", "Try Again");
        }
    }

        // Function of saving new item 
    function savenewitem() {
        if ($("#NewItemForm").valid()) {
            var imagefile = newimg;

                itemName = $("#itemName").val();
                categoryID = $("#categoryID").val();
                description = $("#description").val();
                price = $("#price").val();
           
                if (_validate()) {
                    var url = serverURL() + "/newitem.php";

                    var JSONObject = {

                        "itemName": itemName,
                        "categoryID": categoryID,
                        "description": description,
                        "price": price,
                        "imagefile": imagefile
                    };

                    $.ajax({
                        url: url,
                        type: 'GET',
                        data: JSONObject,
                        dataType: 'json',
                        contentType: "application/json; charset=utf-8",
                        success: function (arr) {
                            _getNewUserResult(arr);
                        },
                        error: function () {
                            validationMsg();
                        }
                    });
                }
            }

        }

    function _validate() {
        var validate = true;

        if (newimg === "") {
            validationMsgs("Select a photo", "Validation", "OK");
            validate = false;
        }
        return validate;
    }

    function _getNewUserResult(arr) {
        if (arr[0].result === 1) {
            validationMsgs("New Item created", "Validation", "OK");
            
        }

        else {

            validationMsgs("Item ID already exist", "Validation", "OK");
        }
    }




})();