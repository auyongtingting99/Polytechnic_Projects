﻿(function () {
    var orders;
    //pagebeforecreate is an event JUST BEFORE this page is shown to the user
    $(document).on("pagebeforecreate", function () {
        printheader(); //execute printheader first before this page is shown to the user 
    });

    $(document).ready(function () {

        itemdetails(); // executes listitems()

        $("#btnOrder").bind("click", function () {
            newOrder();
        });

    });

    ///Display of Items from the Database 
    function itemdetails(itemID) {
        var url = serverURL() + "/getitembyid.php"; // run getitembyid
        newitemID = decodeURIComponent(getUrlVars()["itemID"]);

        var JSONObject = {
            "itemID": decodeURIComponent(getUrlVars()["itemID"])// provide "itemID" to run getprofile.php
        };

        $.ajax({
            url: url,
            type: 'GET',
            data: JSONObject,
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function (arr) {
                _showitemdetails(arr); // sucessful call, execute _showfriendResult()
            },
            error: function () {
                validationMsg();
            }
        });
    }

    function _showitemdetails(arr) {
        $("#imgitemimage").attr("src", serverURL() + "/images/" + arr[0].imagefile);
        $("#itemName").html("Item name: " + arr[0].itemName);
        $("#price").html("Price: $" + arr[0].price);
        $("#description").html("Description: " + arr[0].description);

        localStorage.setItem("price", arr[0].price);
    }

    /// Making a new order, entering into the database 
    function newOrder() {
        var requestedDateTime = $("#requestedDateTime").val();
        //var specialrequest = $("#specialrequest").val();
        var quantity = $("#quantity").val();
        var orderaddress = $("#orderaddress").val();
        var request = $("#request").val();
        var url = serverURL() + "/placeorder.php"; // run getitembyid
        newitemID = decodeURIComponent(getUrlVars()["itemID"]);

        var JSONObject = {
            "userID": localStorage.getItem("userid"),
            "itemID": decodeURIComponent(getUrlVars()["itemID"]),// provide "itemID" to run placeorder.php
            "price": localStorage.getItem("price"),
            "quantity": quantity,
            "requestedDateTime": requestedDateTime,
            "status": "ord",
            "orderaddress": orderaddress,
            "request": request
            //"specialrequest": specialrequest,
            


        };

        $.ajax({
            url: url,
            type: 'GET',
            data: JSONObject,
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function (arr) {
                _newOrder(arr); // sucessful call, execute _showfriendResult()
            },
            error: function () {
                validationMsg();
            }
        });
    }

    function _newOrder(arr) {
        if (arr[0].result === 1) {
            validationMsgs("Order submitted", "Validation", "OK");
            window.location = "catalog.html";
        }
        else {
            validationMsgs("Order failed, Please try again", "Validation", "Try Again");
        }
    }

   
})();