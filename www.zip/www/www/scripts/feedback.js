﻿(function () {

   
                      
    var feedback;            
    var contact;                    
    var email;    

    $(document).on("pagebeforecreate", function () {
        printheader();
    });

    $(document).ready(function () {
        getProfile();
      
        $("#FeedbackForm").validate({
            rules: {
                txtContact: {
                    number: true
                }
            },
            messages: {
               
                txtfeedback: "please enter your feedback",
                txtContact: "enter valid phone number"
            },
            focusInvalid: false,
            submitHandler: function () {
                return false;
            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().parent().after());
            }
        });

       
        $("#btnSubmit").bind("click", function () {
            submitform();
        });
    });

    function getProfile() {
        var url = serverURL() + "/getuser.php";
        var JSONObject = {
            "userid": localStorage.getItem("userid")
        };
        $.ajax({
            url: url,
            type: 'GET',
            data: JSONObject,
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function (arr) {
                _getProfileResult(arr);
            },
            error: function () {
                validationMsg();
            }
        });
    }
    function _getProfileResult(arr) {
        userid = arr[0].userid;
        email = arr[0].email;
        password = arr[0].password;
        address = arr[0].address;
        image = arr[0].image;

        $("#txtuserid").html("User ID: " + userid);
        $("#txtEmail").html("Email: " + email);
        $("#txtAddress").val(address);
        $("#imgProfileImage").attr("src", serverURL() + "/images/" + arr[0].image);
    }

   
    function submitform() {
        if ($("#FeedbackForm").valid()) {  
             
            firstname = $("#txtName").val();
            lastname = $("#txtName1").val();
            feedback = $("#txtfeedback").val(); 
            ratings = $("#ratings").val();
            


                                            
                var url = serverURL() + "/contactus.php";        

              
                var JSONObject = {

                    "firstname": firstname,
                    "lastname": lastname,
                    "feedback": feedback,
                    "ratings" : ratings
                    
                };

                $.ajax({
                    url: url,
                    type: 'GET',
                    data: JSONObject,
                    dataType: 'json',
                    contentType: "application/json; charset=utf-8",
                    success: function (arr) {
                        _getFeedback(arr);                   
                    },
                    error: function () {
                        validationMsg();                         
                    }
                });
            
        }
    }

   
    function _getFeedback(arr) {
        if (arr[0].result === 1) {
            localStorage.setItem("userid", userid);

            validationMsgs("Feedback form submitted", "Validation", "OK");

        }
        else {
            validationMsgs("Feedback form is incomplete", "Validation", "OK");
        }
    }

})();