﻿(function () {

    //pagebeforecreate is an event JUST BEFORE this page is shwon tot he user
    $(document).on("pagebeforecreate", function () {
        printheader(); //execute printheader first before this page is shown to the user 
    });

    $(document).ready(function () {
        $("#btnGo").bind("click", function () {


            displayorders();

        });

    });


    function displayorders() {
        var status = $("#transaction").val();

        var url = serverURL() + "/getmyorders.php"; // run listitems


        var JSONObject = {
            "userID": localStorage.getItem("userid"),
            "status": status
        };

        $.ajax({
            url: url,
            type: 'GET',
            data: JSONObject,
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function (arr) {
                _showOrders(arr); // sucessful call, execute _showOrders
            },
            error: function () {
                validationMsg();
            }
        });
    }



    function _showOrders(arr) {
        var t;

        if ($.fn.dataTable.isDataTable("#search")) {
            t = $('#search').DataTable();
        }
        else {
            t = $('#search').DataTable({
                "searching": false,
                "lengthChange": false
            });
        }
        t.clear();
        for (var i = 0; i < arr.length; i++) {
            t.row.add([
                "<img src='" + serverURL() + "/images/" + arr[i].imagefile + "_s" + "' width='50'>",
                arr[i].price,
                arr[i].requestedDateTime,
                arr[i].status,
                "<a href='#' class='ui-btn' id='btn" + arr[i].orderID + "'>View Orders</a>"
            ]).draw(false);

            
            $("#btn" + arr[i].orderID).bind("click", { id: arr[i].orderID }, function (event) {
                var data = event.data;
                showorderdetails(data.id);

            });



        }
        $("#search").show();

    }

    function showorderdetails(orderID) {
        window.location = "orderdetails.html?orderID=" + orderID;
        
    }
})();
