﻿(function () {

    var orderdetails; 

    //pagebeforecreate is an event JUST BEFORE this page is shwon tot he user 
    $(document).on("pagebeforecreate", function () {
        printheader(); //execute printheader first before this page is shown to the user 
    });

    $(document).ready(function () {

        showorderdetails();

    });

    function showorderdetails() {

        var url = serverURL() + "/getorderbyid.php";

        orderdetails = decodeURIComponent(getUrlVars()["orderID"]);

        var JSONObject = {
            "orderID": decodeURIComponent(getUrlVars()["orderID"])
        };

        $.ajax({
            url: url,
            type: 'GET',
            data: JSONObject,
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function (arr) {
                _getorderDetails(arr); // success! execute _getCategories()
            },
            error: function () {
                validationMsg(); // fail, show error message
            }
        });

    }


    function _getorderDetails(arr) {


        $("#imgOrderImage").attr("src", serverURL() + "/images/" + arr[0].imagefile);
        $("#lblitemName").html("Item: " + arr[0].itemName);
        $("#lblprice").html("Price: $" + arr[0].price);
        $("#lbldescription").html("Quantity: " + arr[0].quantity);
        $("#lblreqDT").html("Requested Date Time : " + arr[0].requestedDateTime);
        $("#lbldelDT").html("Delivered Date Time: " + arr[0].deliveredDateTime);


    }

   








})();