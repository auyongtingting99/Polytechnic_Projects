﻿(function () {

    var imgNewUserPictureName = ""; 
    var userid;                    
    var password;                   
    var passwordagain;              //stores new user's password again
    var address;                    // stores new user's description
    var email;                      // stores new user email

    $(document).ready(function () {
        //valdate the user's input 
        $("#NewUserForm").validate({
            rules: {
                txtNewEmail: {
                    email: true
                },
                txtNewPasswordAgain: {
                    equalTo: "#txtNewPassword"
                }
            },
            messages: {
                txtNewName: "new user name is required",
                txtNewEmail: "new email address is required and must be of the format a@b.c",
                txtNewPassword: "new password is required",
                txtNewPasswordAgain: "new password again is required and must be the same as new password"
            },
            focusInvalid: false,
            submitHandler: function () {
                return false;
            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().parent().after());
            }
        });

        //user presses button to select an image to use as his profile image  
        $("#btnSelectImg").bind("click", function () {
            capturePhoto();
        });

        $("#btnCreateAccount").bind("click", function () {
            savenewuser();
        });
    });

    //CREATING USER PROFILE

    //executes when the user confirms that he wishes to create an account 
    function savenewuser() {
        if ($("#NewUserForm").valid()) {   //validate his inputs 
            /*
                check that email is valid e.g. a@b.c
                passwords are the same 
            */
            var profileimage = imgNewUserPictureName;           // the user would selected a picture, copy the filename to profile image

            userid = $("#txtNewName").val();                    // copy new user name to userid
            email = $("#txtNewEmail").val();                    // copy new email textfield to email
            password = $("#txtNewPassword").val();              //copy password textfield to passsword 
            passwordagain = $("#txtNewPasswordAgain").val();    // copy passswordagian textfield to description 
            address = $("#txtaddress").val();                   // copy description textfield to decription


            if (_validate()) {                                  //executes_validate()
                var url = serverURL() + "/newuser.php";         //call newuser.php

                //call with the following parameters
                var JSONObject = {
                    "userid": userid,
                    "password": password,
                    "email": email,
                    "address": address,
                    "profileimage": imgNewUserPictureName
                };

                $.ajax({
                    url: url,
                    type: 'GET',
                    data: JSONObject,
                    dataType: 'json',
                    contentType: "application/json; charset=utf-8",
                    success: function (arr) {
                        _getNewUserResult(arr);                     //successfully run newuser.php, executes _getNewUserResult()
                    },
                    error: function () {
                        validationMsg();                            //newuser.php didn't respond 
                    }
                });
            }
        }
    }

    //executes on successful call to newuser.php
    function _getNewUserResult(arr) {
        if (arr[0].result === 1) {                                       //successful insertion!
            localStorage.setItem("userid", userid);                      //save userid in localstorage
            localStorage.setItem("password", password);                  //save password in localstorage
                                                                         //window.plugins.OneSignal.sendTag("email", email);
            validationMsgs("New User created", "Validation", "OK");      //tell user that its successful
            window.location = "catalog.html";                                //redirect user to catalog.html 
        }
        else {
            validationMsgs("User ID already exist", "Validation", "OK"); //can't insert because of duplicates 
        }
    }




    //CREATING AND UPLOADING IMAGE/PHOTO 

    //checkes if the user selected a photo 
    function _validate() {
        var validate = true;

        //if imgNewUserPictiureName does not contain the filename of the photo, the user didn't choose a job
        //pop an error message and do not let him continue 
        //if you are testing this on a real andriod phone, document / un-comment this and let it run.
        
        if (imgNewUserPictureName === "") {
            validationMsgs("Select a photo", "Validation", "OK");
            validate = false;
        }
        
        return validate;
    }

    //open the mobile device's gallery to let user choose an image 
    function capturePhoto() {
        var source = navigator.camera.PictureSourceType.PHOTOLIBRARY;
        navigator.camera.getPicture(_onPhotoURISuccess, _failCapture, { quality: 50, destinationType: navigator.camera.DestinationType.FILE_URI, sourceType: source });
    }
    function _failUpload(error) {
        validationMsgs("Error:" + error.code, "Upload Error", "Try Again");
    }

    function _failCapture(message) {
        validationMsgs("Error:" + message, "Image Error", "Try Again");
    }
    function _onPhotoURISuccess(imageURI) {
        var options = new FileUploadOptions();
        options.fileKey = "file";
        options.fileName = imageURI.substr(imageURI.lastIndexOf('/') + 1);
        options.mimeType = "image/jpeg";
        var params = new Object();
        params.value1 = "test";
        params.value2 = "param";
        options.params = params;
        options.chunkedMode = false;
        options.headers = { Connection: "close" };
        var ft = new FileTransfer();
        ft.upload(imageURI, serverURL() + "/upload.php", _winUpload, _failUpload, options);
    }
    function _winUpload(r) {
        if (imgNewUserPictureName !== "") {
            _deleteOldImg(imgNewUserPictureName);
        }
        var arr = JSON.parse(r.response);
        imgNewUserPictureName = arr[0].result;
        $("#imgNewUser").attr("src", serverURL() + "/images/" + imgNewUserPictureName + "_s");
    }
    function _deleteOldImg(oldImg) {
        var url = serverURL() + "/deleteimg.php";
        var JSONObject = {
            "imgfile": oldImg
        };

        $.ajax({
            url: url,
            type: 'GET',
            data: JSONObject,
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function (arr) {
                _deleteImgResult(arr);
            },
            error: function () {
                validationMsg();
            }
        });
    }

    function _deleteImgResult(arr) {
        if (arr[0].result !== "1") {
            validationMsgs("Error deleteing old image", "Upload Error", "Try Again");
        }
    }

}) ();