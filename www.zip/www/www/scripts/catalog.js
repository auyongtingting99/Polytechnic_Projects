﻿(function () {

   
    $(document).on("pagebeforecreate", function () {
        printheader(); 
    });

    $(document).ready(function () {

        getCategories();
       

    });

    function getCategories() {

        var url = serverURL() + "/getcategories.php";

       
        $.ajax({
            url: url,
            type: 'GET',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function (arr) {
                _getCategories(arr); // success! execute _getCategories()
            },
            error: function () {
                validationMsg(); // fail, show error message
            }
        });

    }
  

    function _getCategories(arr) {


        for (var i = 0; i < arr.length; i++) {
                                                                                                     
            $("#categoryid").append("<a href='#' class='ui-btn' id='btn" + arr[i].categoryID + "'>" + arr[i].categoryname + "</a>");// append btn to div and display the btn name with the category names

                

            $('#btn' + arr[i].categoryID).bind("click", { id: arr[i].categoryID, name: arr[i].categoryname } , function (event) {
                    
                var data = event.data;
                
                showcategory(data.id, data.name);// the action to bind to each button to showcategory()
                
            });
        }

        
    }
    
    function showcategory(categoryID, categoryname) {
        // go to showcategory.html?categoryname = the user you choose>
        
        window.location = "listitems.html?categoryID=" + categoryID + "&categoryname=" + categoryname;
       
       
    }

    
            
    

    
        
        

    


})();