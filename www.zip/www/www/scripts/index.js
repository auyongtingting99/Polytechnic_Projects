﻿(function () {
    "use strict";

    var userid;
    var password;
   
    

    $(document).ready(function () {

        $("#LoginForm").validate({
            messages: {
                txtLogin: "User ID is required",
                txtPassword: "Password is required",
            },
            focusInvalid: false,
            submitHandler: function () {
                return false;
            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().parent().after());
            },
        });

        $("#btnLogin").bind("click", function () {
            if ($("#LoginForm").valid()) {
                login();
            }
        });

        $("#btnNewUser").bind("click", function () {
            window.location = "newuser.html";
        });

    }); 

    function login() {
        var url = serverURL() + "/login_customer.php"; //Set the URL to be https//yourserver.org/friendszone/login.php
        var result;
        userid = $("#txtLogin").val(); // what did the user enter in the txtlogin? Copy the value to userid
        password = $("#txtPassword").val(); //what did the user enter in the txtpassword? Copy the value to password

        //Like how we said login.php?userid=jimmy&password=jimmy
        //form the parameter userid and password with the values if userid and password entered by the user
        var JSONObject = {
            "userid": userid,
            "password": password
        };

        //make a call to the server 
        $.ajax({
            url: url,//this is the server's url
            type: 'GET',
            data: JSONObject, // this is the userid and password to pass to login.php in the server 
            dataType: 'json', // we are receiving the JSON kdata 
            contentType: "application/json; charset=utf-8", // this is the properties of the JSON data we receive 
            success: function (arr) { //the call to the server is successful. Server is not down.
                _getLoginResult(arr); // call the function_getLoginResult
            },
            error: function () {
                validationMsg(); //there's and error. maybe server is down? maybe you are disconnected from th internet
            }
        });
    }

    //this function is called when the server call to login.php is successful
    function _getLoginResult(arr) {
        if (arr[0].result.trim() !== "0") { //did login.php return 0? If it didn't, it means the login is successful
            localStorage.setItem("userid", userid); //save this user id in localstorage. we will use it later
            localStorage.setItem("password", password); // save this password in localstorage. we will use it later
            //validationMsgs("Login OK", "Information", "OK"); say login is ok
            window.location = "catalog.html"; 
        }
        else {
            validationMsgs("Error in Username or Password", "Validation", "Try Again"); //wrong userid/password
        }
    }
} )();