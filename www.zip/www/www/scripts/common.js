﻿function serverURL() {
    return "https://1602348c.projectsbit.org/pizzaplace";
}


function getRadioValue(groupName) {
    var _result;
    try {
        var o_radio_group = document.getElementsByName(groupName);
        for (var a = 0; a < o_radio_group.length; a++) {
            if (o_radio_group[a].checked) {
                _result = o_radio_group[a].value;
                break;
            }
        }
    } catch (e) { }
    return _result;
}

function validationMsgs(message, title, button) {
    navigator.notification.alert(
        message,
        function () { },
        title,
        button
    );
}

function validationMsg() {
    navigator.notification.alert(
        "Server Error",
        function () { },
        "Error",
        "OK"
    );
}

function round(number, decimals) {
    return +(Math.round(number + "e+" + decimals) + "e-" + decimals);
}


function printheader() { //created instead of putting it in html as it needs to be used in every webpage and it will be troublesome to do the same thing over and over again. 
    $("#header").html("<h1>Pizza Place</h1>"); //displays the header FriendsZone 
    //prints the Home and Login button 
    $("#header").append("<a href='#' id='btnHome' class='ui-btn ui-icon-home ui-btn-icon-left'>Home</a><a href='#' id='btnLogout' data-icon='power' class='ui-btn-right'>Logout</a>");

    //draws the navigation bar with the buttons for location, profile and search
    var navbarstr = "<div data-role='navbar'><ul>";
    navbarstr += "<li><a id='btnOrder' href='#' data-icon='shop'>Orders</a></li>";
    navbarstr += "<li><a id='btnProfile' href='#' data-icon='user'>Profile</a></li>";
    navbarstr += "<li><a id='btnFeedback' href='#' data-icon='edit'>Feedback</a></li>";
    navbarstr += "</ul></div>";

    //attach the navigation bar to the header
    var myNavbar = $(navbarstr);
    $("#header").append(myNavbar).trigger('create');

    $("#btnOrder").bind("click", function () {
        window.location = "transaction.html";
    });

    $("#btnProfile").bind("click", function () {
        window.location = "profile.html";
    });

    $("#btnFeedback").bind("click", function () {
        window.location = "feedback.html";
    });

    $("#btnHome").bind("click", function () {
        window.location = "catalog.html";
    });

    $("#btnLogout").bind("click", function () {
        localStorage.removeItem("userid");      //remove userid from localstorage
        localStorage.removeItem("password");    //remove password from localstorage
        window.location = "index.html";         //redirect user back to index.html
    });
}

function getUrlVars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function (m, key, value) {
        vars[key] = value;
    });
    return vars;
}

