﻿(function () {

    //pagebeforecreate is an event JUST BEFORE this page is shwon tot he user
    $(document).on("pagebeforecreate", function () {
        printheader(); //execute printheader first before this page is shown to the user 
    });

    $(document).ready(function () {

        listitems(); // executes listitems()

        
       
    });

    
    function listitems(categoryID, categoryname) {
        var url = serverURL() + "/listitems.php"; // run listitems

        newcategoryID = decodeURIComponent(getUrlVars()["categoryID"]);
        newcategoryname = decodeURIComponent(getUrlVars()["categoryname"]);

        var JSONObject = {
            "categoryID": decodeURIComponent(getUrlVars()["categoryID"])// provide "categoryID" to run getprofile.php
        };

        $.ajax({
            url: url,
            type: 'GET',
            data: JSONObject,
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function (arr) {
                _showitemlist(arr); // sucessful call, execute _showfriendResult()
            },
            error: function () {
                validationMsg();
            }
        });
    }

   
        
    function _showitemlist(arr) {
        var i;
        
        $("#lblcategoryname").html("<b>" + "Category >" + "<b>" + newcategoryname);
        $("#listitem").empty();

        for (i = 0; i < arr.length; i++) {

            $("#listitem").append("<img src='" + serverURL() + "/images/" + arr[i].imagefile + "' width='100'>" + "</br>" + "Item ID: " + arr[i].itemID + "</br>" + "Item Name: " + arr[i].itemName + "</br>" + "Price: $" + arr[i].price + "</br>" + "<a href='#' class='ui-btn' id='btn" + arr[i].itemID + "'>View Details</a>");

            
            $("#btn" + arr[i].itemID).bind("click", { id: arr[i].itemID }, function (event) {
                var data = event.data;
                showorders(data.id);

            });

        
        }

    }
           
    function showorders(itemID) {
        window.location = "details.html?itemID=" + itemID;
        localStorage.setItem("itemID", itemID);
    }     
})();
