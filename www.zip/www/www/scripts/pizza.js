﻿(function () {

//pagebeforecreate is an event JUST BEFORE this page is shwon tot he user
$(document).on("pagebeforecreate", function () {
    printheader(); //execute printheader first before this page is shown to the user 
    });

$(document).ready(function () {

    

});
})();
